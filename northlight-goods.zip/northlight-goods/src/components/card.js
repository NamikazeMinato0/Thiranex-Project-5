import { h, money, announce } from "../lib/dom.js";
import { productImage } from "../lib/image.js";
import { cart } from "../store.js";

export function card(p, { eager = false } = {}) {
  const href = `/product/${p.id}`;
  return h("li", {},
    h("article", { class: "card" },
      h("a", { href, "data-link": "", "aria-label": `${p.name}, ${money(p.price)}` },
        // explicit width/height reserve space so the layout never jumps (CLS); lazy-load below the fold
        h("img", { src: productImage(p), alt: "", width: 240, height: 240, loading: eager ? "eager" : "lazy", decoding: "async" })),
      h("h3", {}, h("a", { href, "data-link": "" }, p.name)),
      h("p", { class: "price" }, money(p.price)),
      h("button", { type: "button", "aria-label": `Add ${p.name} to cart`, onclick: () => { cart.add(p.id); announce(`Added ${p.name} to cart.`); } }, "Add to cart")));
}
