import { createRouter } from "./router.js";
import { cart } from "./store.js";
import { announce } from "./lib/dom.js";

const outlet = document.getElementById("main");

const router = createRouter({
  outlet,
  // Each view is a dynamic import, so Vite emits one small chunk per route (code splitting).
  routes: [
    { path: "/", load: () => import("./views/catalog.js") },
    { path: "/product/:id", load: () => import("./views/product.js") },
    { path: "/cart", load: () => import("./views/cart.js") }
  ],
  notFound: () => import("./views/notfound.js"),
  onRender(view, { initial, path }) {
    document.title = `${view.title} · Northlight Goods`;
    document.querySelectorAll(".site-nav a").forEach(a => {
      const on = a.pathname === path || (a.pathname === "/" && path.startsWith("/product"));
      a.toggleAttribute("aria-current", on);
      if (on) a.setAttribute("aria-current", "page");
    });
    if (!initial) { scrollTo(0, 0); outlet.focus({ preventScroll: true }); announce(`${view.title} page`); }
  }
});

const badge = document.getElementById("cart-count");
const updateBadge = () => { badge.textContent = cart.count(); };
cart.subscribe(updateBadge);
updateBadge();
router.start();
