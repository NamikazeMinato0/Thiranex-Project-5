import { h, money, announce } from "../lib/dom.js";
import { cart } from "../store.js";

export default function cartView() {
  const root = h("div", { class: "wrap" });
  let ordered = false;

  function render() {
    const items = cart.items();
    root.replaceChildren(h("h1", {}, "Your cart"));
    if (ordered) return root.append(h("p", { class: "lede" }, "Thanks. This is a demo shop, so no order was placed."), h("a", { class: "btn", href: "/", "data-link": "" }, "Keep browsing"));
    if (!items.length) return root.append(h("p", { class: "lede" }, "Your cart is empty."), h("a", { class: "btn", href: "/", "data-link": "" }, "Browse products"));
    root.append(
      h("ul", { class: "lines" }, items.map(({ product: p, qty }) => h("li", { class: "line", "data-id": p.id },
        h("a", { href: `/product/${p.id}`, "data-link": "" }, p.name),
        h("label", { class: "vh", htmlFor: `q-${p.id}` }, `Quantity for ${p.name}`),
        h("input", { id: `q-${p.id}`, type: "number", min: 1, max: 99, value: qty, "data-act": "qty" }),
        h("span", { class: "price" }, money(p.price * qty)),
        h("button", { type: "button", "data-act": "remove", "aria-label": `Remove ${p.name}` }, "Remove")))),
      h("p", { class: "total" }, `Total: ${money(cart.total())}`),
      h("button", { type: "button", class: "primary", "data-act": "checkout" }, "Place demo order"));
  }

  // Event delegation: two listeners handle every line item, however many exist
  root.addEventListener("click", e => {
    const act = e.target.closest("[data-act]")?.dataset.act, id = e.target.closest("[data-id]")?.dataset.id;
    if (act === "remove") { cart.remove(id); announce("Item removed."); render(); root.querySelector("a,button")?.focus(); }
    if (act === "checkout") { cart.clear(); ordered = true; render(); announce("Demo order placed."); }
  });
  root.addEventListener("change", e => {
    if (e.target.dataset.act !== "qty") return;
    const id = e.target.closest("[data-id]").dataset.id;
    cart.setQty(id, Math.max(0, Math.min(99, Number(e.target.value) || 0)));
    render();
    root.querySelector(`[data-id="${id}"] input`)?.focus();
  });
  render();
  return { title: "Cart", node: root };
}
