import { h } from "../lib/dom.js";
export default function notFound() {
  return { title: "Page not found", node: h("div", { class: "wrap" }, h("h1", {}, "Page not found"), h("p", {}, "That page doesn’t exist or the product was removed."), h("a", { class: "btn", href: "/", "data-link": "" }, "Back to the shop")) };
}
