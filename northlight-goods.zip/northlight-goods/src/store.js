import { getProduct } from "./data/products.js";
const KEY = "northlight.cart.v1";
let items = load();
const listeners = new Set();

function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(raw) ? raw.filter(i => getProduct(i?.id) && Number.isInteger(i.qty) && i.qty > 0) : [];
  } catch { return []; }
}
function commit() {
  try { localStorage.setItem(KEY, JSON.stringify(items)); } catch { /* private mode */ }
  listeners.forEach(fn => fn());
}

export const cart = {
  items: () => items.map(i => ({ ...i, product: getProduct(i.id) })),
  count: () => items.reduce((n, i) => n + i.qty, 0),
  total: () => items.reduce((n, i) => n + i.qty * getProduct(i.id).price, 0),
  add(id, qty = 1) { const i = items.find(x => x.id === id); i ? (i.qty = Math.min(i.qty + qty, 99)) : items.push({ id, qty }); commit(); },
  setQty(id, qty) { qty < 1 ? this.remove(id) : (items.find(x => x.id === id).qty = Math.min(qty, 99), commit()); },
  remove(id) { items = items.filter(i => i.id !== id); commit(); },
  clear() { items = []; commit(); },
  subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
};
