export const categories = [
  { id: "desk", label: "Desk" }, { id: "home", label: "Home" }, { id: "carry", label: "Carry" }
];
export const products = [
  { id: "oak-riser", name: "Oak monitor riser", cat: "desk", price: 68, hue: 35, desc: "Solid oak stand that lifts your screen to eye level and hides a keyboard underneath." },
  { id: "felt-mat", name: "Felt desk mat", cat: "desk", price: 34, hue: 215, desc: "A wool-felt mat that quiets typing and protects the desk surface." },
  { id: "brass-cup", name: "Brass pen cup", cat: "desk", price: 22, hue: 48, desc: "Weighted brass cup that stays put when you pull a pen out." },
  { id: "cable-tray", name: "Cable tray", cat: "desk", price: 18, hue: 160, desc: "Clips under the desk and keeps power strips and cables off the floor." },
  { id: "stone-mugs", name: "Stoneware mug set", cat: "home", price: 38, hue: 12, desc: "Set of two hand-glazed mugs. Dishwasher and microwave safe." },
  { id: "linen-throw", name: "Linen throw", cat: "home", price: 72, hue: 190, desc: "Stonewashed linen throw that gets softer with every wash." },
  { id: "glass-carafe", name: "Glass carafe", cat: "home", price: 29, hue: 200, desc: "One-litre borosilicate carafe with a lid that doubles as a cup." },
  { id: "soy-candle", name: "Soy candle", cat: "home", price: 24, hue: 95, desc: "Cedar and sage scent, about 45 hours of burn time." },
  { id: "canvas-tote", name: "Canvas tote", cat: "carry", price: 42, hue: 25, desc: "Heavy cotton canvas tote with an inside zip pocket." },
  { id: "weekender", name: "Weekender bag", cat: "carry", price: 128, hue: 260, desc: "Water-resistant duffel with a shoe compartment and a laptop sleeve." },
  { id: "card-wallet", name: "Card wallet", cat: "carry", price: 36, hue: 340, desc: "Slim vegetable-tanned leather wallet that holds six cards and folded notes." },
  { id: "cord-pouch", name: "Cord pouch", cat: "carry", price: 19, hue: 130, desc: "Zip pouch with elastic loops for chargers, cables and earbuds." }
];
export const getProduct = id => products.find(p => p.id === id);
