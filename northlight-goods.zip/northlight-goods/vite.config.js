import { defineConfig } from "vite";
// Vite minifies JS/CSS with esbuild, splits each route into its own chunk, and hashes file names for long-term caching.
export default defineConfig({ build: { target: "es2022", cssCodeSplit: true, sourcemap: false } });
