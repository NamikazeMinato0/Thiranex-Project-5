import { h } from "../lib/dom.js";
import { products, categories } from "../data/products.js";
import { card } from "../components/card.js";

const sorters = { featured: () => 0, low: (a, b) => a.price - b.price, high: (a, b) => b.price - a.price, name: (a, b) => a.name.localeCompare(b.name) };

export default function catalog({ query }) {
  // Filter state lives in the URL, so every filtered view is shareable and survives refresh.
  const s = { q: query.get("q") ?? "", cat: query.get("cat") ?? "all", sort: query.get("sort") ?? "featured" };
  const grid = h("ul", { class: "grid" });
  const count = h("p", { class: "muted", role: "status" });

  function update() {
    const q = s.q.trim().toLowerCase();
    const list = products
      .filter(p => (s.cat === "all" || p.cat === s.cat) && (!q || `${p.name} ${p.desc}`.toLowerCase().includes(q)))
      .sort(sorters[s.sort] || sorters.featured);
    grid.replaceChildren(...(list.length ? list.map((p, i) => card(p, { eager: i < 4 })) : [h("li", { class: "empty" }, "No products match. Try a different search or category.")]));
    count.textContent = `${list.length} ${list.length === 1 ? "product" : "products"}`;
    const p = new URLSearchParams();
    if (s.q) p.set("q", s.q);
    if (s.cat !== "all") p.set("cat", s.cat);
    if (s.sort !== "featured") p.set("sort", s.sort);
    history.replaceState({}, "", location.pathname + (p.toString() ? `?${p}` : ""));
  }

  const select = (id, label, opts, value) => h("div", { class: "field" },
    h("label", { htmlFor: id }, label),
    h("select", { id }, opts.map(([v, t]) => h("option", { value: v, selected: v === value }, t))));

  const controls = h("form", { class: "controls", role: "search", onsubmit: e => e.preventDefault(),
    oninput: e => { const t = e.target; if (t.id === "q") s.q = t.value; if (t.id === "cat") s.cat = t.value; if (t.id === "sort") s.sort = t.value; update(); } },
    h("div", { class: "field grow" }, h("label", { htmlFor: "q" }, "Search products"), h("input", { id: "q", type: "search", value: s.q, autocomplete: "off" })),
    select("cat", "Category", [["all", "All"], ...categories.map(c => [c.id, c.label])], s.cat),
    select("sort", "Sort by", [["featured", "Featured"], ["low", "Price: low to high"], ["high", "Price: high to low"], ["name", "Name"]], s.sort));

  update();
  return { title: "Shop", node: h("div", { class: "wrap" }, h("h1", {}, "Considered goods for desk, home and travel"), controls, count, grid) };
}
