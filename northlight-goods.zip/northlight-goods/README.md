# Northlight Goods: modular storefront

Vanilla ES-module SPA: History API router, lazy-loaded routes, URL-driven filters, localStorage cart, generated SVG imagery, Vite build.

## Structure
- `src/router.js` pattern-matching History API router (lazy `import()` per route)
- `src/store.js` cart state with persistence and subscriptions
- `src/views/` one module per route, `src/components/` reusable UI, `src/lib/` helpers, `src/data/` catalogue
- `vercel.json` / `netlify.toml` SPA rewrites, immutable asset caching, security headers (strict CSP)

## Run
```
npm install
npm run dev        # http://localhost:5173
npm run build      # minified, hashed, code-split output in dist/
npm run preview    # serve the production build locally
```

## Deploy
**Vercel:** `npx vercel --prod` (or import the Git repo; framework preset: Vite).
**Netlify:** `npx netlify deploy --prod --dir=dist` after `npm run build` (or connect the repo: build `npm run build`, publish `dist`).
**Render:** create a Static Site, build `npm install && npm run build`, publish `dist`, add a rewrite `/*` to `/index.html`.
