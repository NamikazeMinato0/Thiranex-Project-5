import { h } from "./lib/dom.js";

/** Minimal History API router: pattern matching, lazy views, link interception. */
export function createRouter({ routes, notFound, outlet, onRender }) {
  const table = routes.map(r => ({ ...r, re: new RegExp(`^${r.path.replace(/:(\w+)/g, "(?<$1>[^/]+)")}/?$`) }));
  let first = true, token = 0;

  async function render() {
    const id = ++token;
    const url = new URL(location.href);
    let load = notFound, params = {};
    for (const r of table) {
      const m = r.re.exec(url.pathname);
      if (m) { load = r.load; params = m.groups || {}; break; }
    }
    let view;
    try {
      view = (await load()).default({ params, query: url.searchParams });
    } catch {
      view = { title: "Something went wrong", node: h("section", { class: "wrap" }, h("h1", {}, "Something went wrong"), h("p", {}, "The page couldn’t load. Check your connection and "), h("button", { type: "button", onclick: render }, "try again")) };
    }
    if (id !== token) return;               // a newer navigation won the race
    outlet.replaceChildren(view.node);
    onRender(view, { initial: first, path: url.pathname });
    first = false;
  }

  function navigate(to) { history.pushState({}, "", to); return render(); }

  document.addEventListener("click", e => {
    const a = e.target.closest("a[data-link]");
    if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    navigate(a.getAttribute("href"));
  });
  addEventListener("popstate", render);
  return { start: render, navigate };
}
