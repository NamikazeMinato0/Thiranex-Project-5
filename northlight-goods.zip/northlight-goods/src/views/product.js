import { h, money, announce } from "../lib/dom.js";
import { getProduct, products } from "../data/products.js";
import { productImage } from "../lib/image.js";
import { card } from "../components/card.js";
import { cart } from "../store.js";
import notFound from "./notfound.js";

export default function product({ params }) {
  const p = getProduct(params.id);
  if (!p) return notFound();
  const related = products.filter(x => x.cat === p.cat && x.id !== p.id).slice(0, 3);
  const qty = h("input", { id: "qty", type: "number", min: 1, max: 99, value: 1 });
  const node = h("div", { class: "wrap" },
    h("p", {}, h("a", { href: "/", "data-link": "" }, "Back to all products")),
    h("div", { class: "detail" },
      h("img", { class: "hero-img", src: productImage(p), alt: `Illustration of the ${p.name}`, width: 480, height: 480 }),
      h("div", {},
        h("h1", {}, p.name), h("p", { class: "price big" }, money(p.price)), h("p", {}, p.desc),
        h("div", { class: "field" }, h("label", { htmlFor: "qty" }, "Quantity"), qty),
        h("button", { type: "button", class: "primary", onclick: () => { const n = Math.max(1, Math.min(99, Number(qty.value) || 1)); cart.add(p.id, n); announce(`Added ${n} × ${p.name} to cart.`); } }, "Add to cart"))),
    h("section", { "aria-labelledby": "rel" }, h("h2", { id: "rel" }, "More from this collection"), h("ul", { class: "grid" }, related.map(r => card(r)))));
  return { title: p.name, node };
}
